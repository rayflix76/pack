#!/usr/bin/python3
xbmc.executebuiltin("Notification(FICHIER TEMP,Effacement en cours...)")
import shutil
dirPath = xbmc.translatePath('special://home/temp/temp/');
# Delete all contents of a directory using shutil.rmtree() and  handle exceptions
try:
   shutil.rmtree(dirPath)
except:
   print('Error while deleting directory')
xbmc.sleep(2000)
xbmc.executebuiltin("Notification(PACK SKIN FULL,Téléchargement en cours...)")
from io import BytesIO
from urllib.request import urlopen
from zipfile import ZipFile
zipurl = 'https://github.com/rayflix76/pack/raw/kodi/test.zip'
with urlopen(zipurl) as zipresp:
    with ZipFile(BytesIO(zipresp.read())) as zfile:
        zfile.extractall('/storage/emulated/0/Android/data/org.xbmc.kodi/files/.kodi/temp/temp')
import shutil
source_dir = xbmc.translatePath('special://home/temp/temp/addon_data')
destination_dir = xbmc.translatePath('special://home/userdata/addon_data')
source_dir2 = xbmc.translatePath('special://home/temp/temp/addons/skin.project.aura')
destination_dir2 = xbmc.translatePath('special://home/addons/skin.project.aura')
shutil.copytree(source_dir, destination_dir, dirs_exist_ok=True)
shutil.copytree(source_dir2, destination_dir2, dirs_exist_ok=True)
xbmc.executebuiltin("Notification(TELECHARGEMENT OK,Mise à jour effectuée !)")
xbmc.sleep(5000)
xbmc.executebuiltin("Notification(ACTUALISATION DU SKIN, Pack Skin Full...)")
xbmc.sleep(4000)
xbmc.executebuiltin('ReloadSkin')
