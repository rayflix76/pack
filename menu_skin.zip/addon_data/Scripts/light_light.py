#!/usr/bin/python3
xbmc.executebuiltin("Notification(PACK SKIN LIGHT,Téléchargement en cours...)")
from io import BytesIO
from urllib.request import urlopen
from zipfile import ZipFile
zipurl = 'https://github.com/rayflix76/pack/raw/kodi/light_light.zip'
with urlopen(zipurl) as zipresp:
    with ZipFile(BytesIO(zipresp.read())) as zfile:
        zfile.extractall('/storage/emulated/0/Android/data/org.xbmc.kodi/files/.kodi/temp/temp')
import shutil
source_dir = r"/storage/emulated/0/Android/data/org.xbmc.kodi/files/.kodi/temp/temp/addon_data"
destination_dir = r"/storage/emulated/0/Android/data/org.xbmc.kodi/files/.kodi/userdata/addon_data"
source_dir2 = r"/storage/emulated/0/Android/data/org.xbmc.kodi/files/.kodi/temp/temp/addons/skin.project.aura"
destination_dir2 = r"/storage/emulated/0/Android/data/org.xbmc.kodi/files/.kodi/addons/skin.project.aura"
shutil.copytree(source_dir, destination_dir, dirs_exist_ok=True)
shutil.copytree(source_dir2, destination_dir2, dirs_exist_ok=True)
xbmc.executebuiltin("Notification(TELECHARGEMENT OK,Mise à jour effectuée !)")
xbmc.sleep(5000)
xbmc.executebuiltin("Notification(ACTUALISATION DU SKIN, Pack Skin Light...)")
xbmc.sleep(2000)
xbmc.executebuiltin('ReloadSkin')